package com.example.apeksha.tanvispin2;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
public class DetailsOfStudent extends AppCompatActivity {



        List<DetailLayout> productList;

        RecyclerView recyclerView;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_app1);





            recyclerView = findViewById(R.id.recycle);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));



            productList = new ArrayList<>();




            productList.add(
                    new DetailLayout(
                            1,
                            "Name",
                            "Questions",
                            "Answers"));
            DetailAdapter adapter = new DetailAdapter(this, productList);


            recyclerView.setAdapter(adapter);
        }
    }

