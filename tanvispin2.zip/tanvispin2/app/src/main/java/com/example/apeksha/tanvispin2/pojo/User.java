package com.example.apeksha.tanvispin2.pojo;

public class User {

    private String Name;
    private String Location;
    private String KEY;
    private String ChatIDs;
    private String ImageURL;
    private String isPremium;
    private String wordCount;
    private String Universities;


    public User(){

    }

    public User(String name, String location, String KEY, String chatIDs, String imageURL, String isPremium, String wordCount, String universities) {
        Name = name;
        Location = location;
        this.KEY = KEY;
        ChatIDs = chatIDs;
        ImageURL = imageURL;
        this.isPremium = isPremium;
        this.wordCount = wordCount;
        this.Universities = universities;
    }

    public String getUniversities() {
        return Universities;
    }

    public void setUniversities(String universities) {
        Universities = universities;
    }

    public String getWordCount() {
        return wordCount;
    }

    public void setWordCount(String wordCount) {
        this.wordCount = wordCount;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getKEY() {
        return KEY;
    }

    public void setKEY(String KEY) {
        this.KEY = KEY;
    }

    public String getChatIDs() {
        return ChatIDs;
    }

    public void setChatIDs(String chatIDs) {
        ChatIDs = chatIDs;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String imageURL) {
        ImageURL = imageURL;
    }

    public String getIsPremium() {
        return isPremium;
    }

    public void setIsPremium(String isPremium) {
        this.isPremium = isPremium;
    }

}
