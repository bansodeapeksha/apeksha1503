package com.example.apeksha.tanvispin2.pojo;

public class ChatMessage {

    String Msg, Receiver, Sender, Timestamp, isSeen, sender_id, type;

    public ChatMessage(){}

    public ChatMessage(String msg, String receiver, String sender, String timestamp, String isSeen, String sender_id, String type) {
        Msg = msg;
        Receiver = receiver;
        Sender = sender;
        Timestamp = timestamp;
        this.isSeen = isSeen;
        this.sender_id = sender_id;
        this.type = type;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String msg) {
        Msg = msg;
    }

    public String getReceiver() {
        return Receiver;
    }

    public void setReceiver(String receiver) {
        Receiver = receiver;
    }

    public String getSender() {
        return Sender;
    }

    public void setSender(String sender) {
        Sender = sender;
    }

    public String getTimestamp() {
        return Timestamp;
    }

    public void setTimestamp(String timestamp) {
        Timestamp = timestamp;
    }

    public String getIsSeen() {
        return isSeen;
    }

    public void setIsSeen(String isSeen) {
        this.isSeen = isSeen;
    }

    public String getSender_id() {
        return sender_id;
    }

    public void setSender_id(String sender_id) {
        this.sender_id = sender_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "ChatMessage{" +
                "Msg='" + Msg + '\'' +
                ", Receiver='" + Receiver + '\'' +
                ", Sender='" + Sender + '\'' +
                ", Timestamp='" + Timestamp + '\'' +
                ", isSeen='" + isSeen + '\'' +
                ", sender_id='" + sender_id + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
