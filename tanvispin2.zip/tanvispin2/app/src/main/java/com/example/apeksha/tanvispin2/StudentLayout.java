package com.example.apeksha.tanvispin2;

public class StudentLayout {




        int id;
        String name;
        String date1;



        public StudentLayout(int i, String name, String date1) {
            this.id = id;
            this.name = name;
            this.date1 = date1;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getDate1() {
            return date1;
        }



}
