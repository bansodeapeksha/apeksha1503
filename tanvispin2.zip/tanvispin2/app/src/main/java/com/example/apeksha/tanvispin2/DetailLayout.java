package com.example.apeksha.tanvispin2;

public class DetailLayout {


        int id;
        String name;
        String Questions,Answers;
        private int title;

        public DetailLayout(int id, String name, String questions, String answers) {
            this.id = id;
            this.name = name;
            this.Questions = questions;
            this.Answers = answers;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getQuestions() {
            return Questions;
        }

        public String getAnswers() {
            return Answers;
        }

        public int getTitle() {
            return title;
        }

    public class ProductViewHolder {
    }
}

