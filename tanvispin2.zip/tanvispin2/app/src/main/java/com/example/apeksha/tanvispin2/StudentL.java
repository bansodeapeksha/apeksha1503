package com.example.apeksha.tanvispin2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apeksha.tanvispin2.pojo.User;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class StudentL extends AppCompatActivity {


    SharedPreferences pref;
    List<User> post = new ArrayList<>();
    List<User> oldposts;
    int listpostid = 0;
    StudentL.MyAdapter adapter;
    Button Add;
    String user_id,view;
    RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;


        List<User> userList = new ArrayList<User>();

        String type;

        FirebaseDatabase database;
        DatabaseReference userRef;

        RecyclerView recyclerView;
        private Object position;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_lay);

            database = FirebaseDatabase.getInstance();
            userRef = database.getReference().child("Users");

//            recyclerView = findViewById(R.id.recy);
//            recyclerView.setHasFixedSize(true);
//            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            type = getIntent().getExtras().getString("type");


            mRecyclerView = (RecyclerView) findViewById(R.id.recy);

            mRecyclerView.setHasFixedSize(true);
            // use a linear layout manager
            mLayoutManager = new LinearLayoutManager(getApplicationContext());
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.smoothScrollToPosition(mLayoutManager.getItemCount());


            post = new ArrayList<>();
            //  adapter = new MyAdapter(getActivity(),R.layout.single_item, post);
            adapter = new StudentL.MyAdapter(getApplicationContext(), R.layout.list_lay, post);
            //lv.setAdapter(adapter);
            mRecyclerView.setAdapter(adapter);

            oldposts = new ArrayList<>();


            if(type.equals("mentor")){
                post = getMentorList();
              //  post = new ArrayList<>();
                //  adapter = new MyAdapter(getActivity(),R.layout.single_item, post);
                adapter = new StudentL.MyAdapter(getApplicationContext(), R.layout.list_lay, post);
                //lv.setAdapter(adapter);
                mRecyclerView.setAdapter(adapter);
//                StudentAdapter adapter = new StudentAdapter(this,userList);
//                recyclerView.setAdapter(adapter);

            }else{
                post = getUserList();

                adapter = new StudentL.MyAdapter(getApplicationContext(), R.layout.list_lay, post);
                //lv.setAdapter(adapter);
                mRecyclerView.setAdapter(adapter);

//                StudentAdapter adapter = new StudentAdapter(this,userList);
//                recyclerView.setAdapter(adapter);
            }





//            Log.d("userList : ",userList.get(0).getName());

//            productList.add(
//                    new StudentLayout(
//                            1,
//                            "Name",
//                            "Date"
//                    ));
//            StudentAdapter adapter4 = new StudentAdapter(this, productList);
//
//
//            recyclerView.setAdapter(adapter4);

        }

    private List<User> getUserList() {

            final List<User> list = new ArrayList<User>();

            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                        Log.d("Snapshot",snapshot.getChildren().toString());
                        User user = snapshot.getValue(User.class);
                        list.add(user);
//                        if(!user.getIsPremium().equals("YES")){
//                            list.add(user);
//                            Log.d("user ",user.getKEY());
//                            Log.d("user ",user.getName());
//                        }
//                        post.addAll(list);
//                        adapter.notifyDataSetChanged();
                    }
                    post.addAll(list);
                    adapter.notifyDataSetChanged();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


            return list;
    }

    private List<User> getMentorList() {

        final List<User> list = new ArrayList<User>();

        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Log.d("Snapshot",snapshot.getChildren().toString());
                    User user = snapshot.getValue(User.class);

                //    Toast.makeText(getApplicationContext(), user.getName(),Toast.LENGTH_LONG).show();

//                    Log.d("user ",user.getKEY());
//                        Log.d("user ",user.getName());
//                        Log.d("user ",user.getIsPremium());

                    list.add(user);

                   // post.addAll(newpost);
                  //  adapter.notifyDataSetChanged();
//                    if(user.getIsPremium().equals("YES")){
//                        list.add(user);
//                        Log.d("user ",user.getKEY());
//                        Log.d("user ",user.getName());
//                        Log.d("user ",user.getIsPremium());
//                    }
                }

                post.addAll(list);
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        return list;
    }



    class MyAdapter extends RecyclerView.Adapter<StudentL.MyAdapter.MYVIEW> {

        private Context context;
        private User user;
        private List<User> pplList;

        public MyAdapter(Context context, int single_user_data_show, List<User> post) {
            this.context = context;
            this.pplList = post;
        }

        @Override
        public StudentL.MyAdapter.MYVIEW onCreateViewHolder(ViewGroup parent, int viewType) {
            View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_lay, parent, false);

            StudentL.MyAdapter.MYVIEW myview = new StudentL.MyAdapter.MYVIEW(layoutView);
            return myview;
        }

        @Override
        public void onBindViewHolder(final StudentL.MyAdapter.MYVIEW holder, final int position) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });



            holder.Name.setText("Name : "+pplList.get(position).getName()+"");

           // Toast.makeText(getApplicationContext(),"Name : "+pplList.get(position).getName(),Toast.LENGTH_LONG).show();
         //   holder.Questions.setText(pplList.get(position).getDescription());
           // holder.Answers.setText(pplList.get(position).getDescription());



        }

        @Override
        public int getItemCount() {
            return pplList.size();
        }

        //   public int getItemViewType(int position) {
//            return (position % MainActivity.ITEMS_PER_AD == 0) ? NATIVE_EXPRESS_AD_VIEW_TYPE
//                    : MENU_ITEM_VIEW_TYPE;
        //   }
        class MYVIEW extends RecyclerView.ViewHolder {

            TextView Name,Questions,Answers;

            public MYVIEW(View itemView) {
                super(itemView);

                Name = (TextView) itemView.findViewById(R.id.name);
                Questions = (EditText) itemView.findViewById(R.id.questions);
                Answers = (EditText) itemView.findViewById(R.id.answers);
            }
        }

    }

}




