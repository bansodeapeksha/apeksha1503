package com.example.apeksha.tanvispin2;

import android.content.Intent;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;

//import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.*;

import java.util.List;

//import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    List<StudentLayout> productList;

    RecyclerView recyclerView;
    private Object position;
    public   Button btnStudent,btnMentor;
    public void init(){


        btnStudent=(Button) findViewById(R.id.btnStudent);
        btnStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,StudentL.class);
                i.putExtra("type","student");
                startActivity(i);
            }
        });

        btnMentor=(Button)findViewById(R.id.btnMentor);
        btnMentor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,StudentL.class);
                i.putExtra("type","mentor");
                startActivity(i);
            }
        });
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner= findViewById(R.id.s1);
        init();
        ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this,R.array.array_countries, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);
        //spinner.setOnItemClickListener(this);


        Spinner spinner1= findViewById(R.id.s2);
        ArrayAdapter<CharSequence> adapter1= ArrayAdapter.createFromResource(this,R.array.array_months, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner1.setAdapter(adapter1);


        Spinner spinner2= findViewById(R.id.s3);
        ArrayAdapter<CharSequence> adapter2= ArrayAdapter.createFromResource(this,R.array.array_years, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner2.setAdapter(adapter2);




    }












    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        //String text=parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}


