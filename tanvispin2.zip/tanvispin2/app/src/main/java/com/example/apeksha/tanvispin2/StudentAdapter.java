package com.example.apeksha.tanvispin2;

import android.content.Context;
import android.content.Intent;
//import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.apeksha.tanvispin2.pojo.User;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<com.example.apeksha.tanvispin2.StudentAdapter.ProductViewHolder>  {



        private Context mCtx;

        //we are storing all the products in a list
        private List<User> productList;

        //getting the context and product list with constructor
        public StudentAdapter(Context mCtx, List<User> productList) {
            this.mCtx = mCtx;
            this.productList = productList;
        }


        public com.example.apeksha.tanvispin2.StudentAdapter.ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //inflating and returning our view holder
            LayoutInflater inflater = LayoutInflater.from(mCtx);
            View view = inflater.inflate(R.layout.app2_lay, null);
            return new ProductViewHolder(view);
        }




    public void onBindViewHolder(com.example.apeksha.tanvispin2.StudentAdapter.ProductViewHolder holder, int position) {
            //getting the product of the specified position


            User product = productList.get(position);

            //binding the data with the viewholder views
            holder.t1.setText(product.getName());
            holder.t2.setText(product.getWordCount());

            Intent i2;
            i2 = new Intent(mCtx, DetailsOfStudent.class);

            mCtx.startActivity(i2);

        }

        @Override
        public int getItemCount() {
            return productList.size();

        }

        public class ProductViewHolder extends RecyclerView.ViewHolder {
            TextView t1, t2;
            EditText e1, e2;

            public ProductViewHolder(View itemView) {
                super(itemView);

                t1 = itemView.findViewById(R.id.t1);

                t2 = itemView.findViewById(R.id.t2);
                e1 = itemView.findViewById(R.id.e1);
                e2 = itemView.findViewById(R.id.e2);

            }

        }
    }




