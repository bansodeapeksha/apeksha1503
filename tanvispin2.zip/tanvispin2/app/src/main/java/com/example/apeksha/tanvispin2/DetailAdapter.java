package com.example.apeksha.tanvispin2;

import android.content.Context;
//import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DetailAdapter extends RecyclerView.Adapter<DetailAdapter.ProductViewHolder> {






        private Context mCtx;

        //we are storing all the products in a list
        private List<DetailLayout> productList;

        //getting the context and product list with constructor
        public DetailAdapter(DetailsOfStudent detailsOfStudent, List<DetailLayout> productList) {
            this.mCtx = mCtx;
            this.productList = this.productList;
        }





        public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //inflating and returning our view holder
            LayoutInflater inflater = LayoutInflater.from(mCtx);
            View view = inflater.inflate(R.layout.list_lay, null);
            return new ProductViewHolder(view);
        }



    public void onBindViewHolder(com.example.apeksha.tanvispin2.DetailAdapter.ProductViewHolder holder, int position) {
            //getting the product of the specified position
            DetailLayout product = productList.get(position);

            //binding the data with the viewholder views
            holder.textViewTitle.setText(product.getName());
            holder.textViewShortDesc.setText(product.getQuestions());
            holder.textView2.setText(product.getAnswers());





        }

        public int getItemCount() {
            return productList.size();
        }

        public class ProductViewHolder extends RecyclerView.ViewHolder {
            TextView textViewTitle,textViewShortDesc,textView2;
            EditText editText,editText4;
            public ProductViewHolder(View itemView) {
                super(itemView);

                textViewTitle = itemView.findViewById(R.id.name);
                textViewShortDesc = itemView.findViewById(R.id.textViewShortDesc);
                textView2=itemView.findViewById(R.id.textView2);
                editText=itemView.findViewById(R.id.questions);
                editText4=itemView.findViewById(R.id.answers);
            }

        }
    }


